var restify = require('restify');
var builder = require('botbuilder');
const _ = require('lodash');
const moment = require('moment');

// Setup Restify Server
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function () {
   console.log('%s listening to %s', server.name, server.url); 
});

// Create chat connector for communicating with the Bot Framework Service
var connector = new builder.ChatConnector({
    appId: process.env.MicrosoftAppId,
    appPassword: process.env.MicrosoftAppPassword
});

// Listen for messages from users 
server.post('/api/messages', connector.listen());

// Receive messages from the user and respond by echoing each message back (prefixed with 'You said:')
const bot = new builder.UniversalBot(connector, [
  session => {
    session.beginDialog('greeting');
  }
]);


bot.dialog('greeting', [
  (session, results, next) => {
    const message = session.message.text.toLowerCase();
    if (message === 'hello') {
      session.endDialog('Hello, gald to see you.');
    } else if (message === 'good morning') {
      session.endDialog('Good morning, How are you?');
    } else if (message === 'adios') {
      session.endDialog('adios amigo');
    } else if (_.includes(message, 'search')) {
      session.beginDialog('searchFlight');
      next();
    } else {
      session.endDialog('Can you please repeat?');
    }
  },
  session => {
    session.endConversation();
  }
]);

var data = {};
// search flight
bot
  .dialog('searchFlight', [
    session => {
      builder.Prompts.text(session, 'Please enter departure city');
    },
    (session, results) => {
      data.depCity = results.response;
      builder.Prompts.text(session, 'Please enter arrival city');
    },
    (session, results) => {
      data.arrivalCity = results.response;
      builder.Prompts.time(session, 'Please enter arrival date');
    },
    (session, results) => {
      data.date = builder.EntityRecognizer.resolveTime([results.response]);
      session.send(`Departure city = **${data.depCity}**, 
                    Arrival city = **${data.arrivalCity}**, 
                    Date = **${data.date}**`);
      builder.Prompts.text(session, 'Do you want to book return flight also ?');
    },
    (session, results) => {
      data.wantReturn = results.response;
      if(data.wantReturn.toLowerCase() === 'NO'.toLowerCase()){
        session.endDialog();
      }
      builder.Prompts.time(session, 'Please enter the return date');
    },
    (session, results) => {
      data.returnDate = builder.EntityRecognizer.resolveTime([results.response]);
      session.endDialog(`Departure city = **${data.arrivalCity}**,
                         Arrival city = **${data.depCity}**,
                         Date = **${data.returnDate}**`);
    }
  ])
  .triggerAction({
    matches: /^(search|find)\s.*flight/i
  });


server.get('/:x/bar', function(req, res, next) {
  console.warn(req.path());
  // => /foo/bar
});