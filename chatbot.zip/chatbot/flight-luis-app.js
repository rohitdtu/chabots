const restify = require('restify');
const builder = require('botbuilder');
const _ = require('lodash');
const moment = require('moment');

// setup restify Server
const port = process.env.port || process.env.PORT || 3978;
const server = restify.createServer();
server.listen(port, () => {
  console.log('Bot is listening to %s', port);
});

// create chat connector for communicating with the Bot Framework Service
const connector = new builder.ChatConnector({
  appId: process.env.MicrosoftAppId,
  appPassword: process.env.MicrosoftAppPassword
});

// listen for messages from users (channel)
server.post('/api/messages', connector.listen());

// create memory storage
const inMemoryStorage = new builder.MemoryBotStorage();

//send message
const bot = new builder.UniversalBot(connector, [
  session => {
    session.beginDialog('greeting');
  }
]).set('storage', inMemoryStorage);

var luisAppId = '929b3137-cb66-435d-a99e-3e42de148bb1';
var luisAPIKey = 'ccf750c102df453f9411a7b3480d9693';
var luisAPIHostName = 'westus.api.cognitive.microsoft.com';

const LuisModelUrl =
  'https://' +
  luisAPIHostName +
  '/luis/v2.0/apps/' +
  luisAppId +
  '?subscription-key=' +
  luisAPIKey;

// Create a recognizer that gets intents from LUIS, and add it to the bot
var recognizer = new builder.LuisRecognizer(LuisModelUrl);
bot.recognizer(recognizer);

const messages = ['Hi', 'Hello', 'Hey there!'];
bot
  .dialog('greeting', session => {
    //send random message
    const msg = _.random(0, messages.length - 1);
    session.send(messages[msg]);
    session.endDialog();
  })
  .triggerAction({
    matches: 'Greeting'
  });

bot
  .dialog('searchFlight', [
    (session, args) => {
      if (args) {
        console.log(args);
        const entities = args.intent.entities;
        session.send('Welcome to flight search service!');

        //dep city
        const depCity = builder.EntityRecognizer.findEntity(
          entities,
          'Flight_Source'
        );
        session.userData.depCity = depCity.entity;

        //arrival city
        const arrivalCity = builder.EntityRecognizer.findEntity(
          entities,
          'Flight_Destination'
        );
        session.userData.arrivalCity = arrivalCity.entity;

        //date
        let date = builder.EntityRecognizer.findEntity(
          entities,
          'builtin.datetimeV2.date'
        );
        date = builder.EntityRecognizer.recognizeTime(date.entity);
        session.userData.date = date.resolution.start.toISOString();

        session.beginDialog('getFlightClass');
      } else {
        session.send('Searching...');
        setTimeout(() => {
          //get values
          const date = moment(session.userData.date).format('DD MMM');
          const depCity = _.capitalize(session.userData.depCity);
          const arrivalCity = _.capitalize(session.userData.arrivalCity);

          //send flight details
          session.send(
            `2 flights found from **${depCity}** to **${arrivalCity}** for ${date}`
          );

          //add adaptive cards
          var cards = [getFlightCard(session), getFlightCard(session)];
          var cardsMsg = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
          session.send(cardsMsg);
          session.endDialog();
        }, 1000);
      }
    }
  ])
  .triggerAction({
    matches: 'SearchFlight'
  });

// flight class dialog
bot.dialog('getFlightClass', [
  session => {
    const msg = new builder.Message(session);
    msg.attachments([
      new builder.HeroCard(session)
        .title('Please select a flight class')
        .buttons([
          builder.CardAction.imBack(
            session,
            'Economy class is selected',
            'Economy'
          ),
          builder.CardAction.imBack(
            session,
            'Business class is selected',
            'Business'
          ),
          builder.CardAction.imBack(session, 'First class is selected', 'First')
        ])
    ]);
    session.send(msg);
    session.endDialog();
  }
]);

bot
  .dialog('selectFlightClass', [
    session => {
      let flightClass = session.message.text;
      flightClass = _.split(flightClass, ' ')[0];
      session.userData.flightClass = flightClass;
      session.beginDialog('searchFlight');
    }
  ])
  .triggerAction({
    matches: /^Economy|Business|First/i
  });

function getFlightCard(session) {
  let amount = '$' + _.random(1000, 5000);
  let airlines = [
    'Jet Airways',
    'Singapore Airlines',
    'Air India',
    'Qatar Airways',
    'Emirates'
  ];
  let airline = airlines[_.random(0, 4)];
  let { depCity, arrivalCity, date, flightClass } = session.userData;
  depCity = _.capitalize(depCity);
  arrivalCity = _.capitalize(arrivalCity);
  let depCityCode = _.upperCase(depCity.substr(0, 3));
  let arrivalCityCode = _.upperCase(arrivalCity.substr(0, 3));
  date = moment(date).toString();

  const card = {
    contentType: 'application/vnd.microsoft.card.adaptive',
    content: {
      $schema: 'http://adaptivecards.io/schemas/adaptive-card.json',
      version: '1.0',
      type: 'AdaptiveCard',
      body: [
        {
          type: 'TextBlock',
          text: airline,
          weight: 'bolder',
          size: 'medium'
        },
        {
          type: 'FactSet',
          separator: true,
          facts: [
            {
              title: 'ID',
              value: _.random(2000, 9999)
            }
          ]
        },
        {
          type: 'FactSet',
          separator: true,
          facts: [
            {
              title: 'Class',
              value: flightClass
            }
          ]
        },
        {
          type: 'ColumnSet',
          separator: true,
          columns: [
            {
              type: 'Column',
              width: 1,
              items: [
                {
                  type: 'TextBlock',
                  text: depCity,
                  isSubtle: true
                },
                {
                  type: 'TextBlock',
                  size: 'Large',
                  color: 'accent',
                  text: depCityCode,
                  spacing: 'none'
                }
              ]
            },
            {
              type: 'Column',
              width: 'auto',
              items: [
                {
                  type: 'TextBlock',
                  text: '&nbsp;'
                },
                {
                  type: 'Image',
                  url: 'http://adaptivecards.io/content/airplane.png',
                  size: 'small',
                  spacing: 'none'
                }
              ]
            },
            {
              type: 'Column',
              width: 1,
              items: [
                {
                  type: 'TextBlock',
                  horizontalAlignment: 'right',
                  text: arrivalCity,
                  isSubtle: true
                },
                {
                  type: 'TextBlock',
                  horizontalAlignment: 'right',
                  size: 'Large',
                  color: 'accent',
                  text: arrivalCityCode,
                  spacing: 'none'
                }
              ]
            }
          ]
        },
        {
          type: 'TextBlock',
          text: 'Non-Stop',
          weight: 'bolder',
          spacing: 'none'
        },
        {
          type: 'TextBlock',
          text: date,
          weight: 'bolder',
          spacing: 'none'
        },
        {
          type: 'ColumnSet',
          separator: true,
          spacing: 'medium',
          columns: [
            {
              type: 'Column',
              width: '1',
              items: [
                {
                  type: 'TextBlock',
                  text: 'Total',
                  size: 'medium',
                  isSubtle: true
                }
              ]
            },
            {
              type: 'Column',
              width: 1,
              items: [
                {
                  type: 'TextBlock',
                  horizontalAlignment: 'right',
                  text: amount,
                  size: 'medium',
                  weight: 'bolder'
                }
              ]
            }
          ]
        }
      ]
    }
  };

  return card;
}
