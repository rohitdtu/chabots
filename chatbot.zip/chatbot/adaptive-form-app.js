const restify = require('restify');
const builder = require('botbuilder');
const _ = require('lodash');
const moment = require('moment');

// setup restify Server
const port = process.env.port || process.env.PORT || 3978;
const server = restify.createServer();
server.listen(port, () => {
  console.log('Bot is listening to %s', port);
});

// create chat connector for communicating with the Bot Framework Service
const connector = new builder.ChatConnector({
  appId: process.env.MicrosoftAppId,
  appPassword: process.env.MicrosoftAppPassword
});

// listen for messages from users (channel)
server.post('/api/messages', connector.listen());

// create memory storage
const inMemoryStorage = new builder.MemoryBotStorage();

//send message
const bot = new builder.UniversalBot(connector, [
  session => {
    session.beginDialog('greeting');
  }
]).set('storage', inMemoryStorage);

// create greeting dialog
bot.dialog('greeting', [
  (session, results, next) => {
    const message = session.message.text.toLowerCase();
    if (message === 'hello') {
      session.endDialog('Hello, gald to see you.');
    } else if (message === 'good morning') {
      session.endDialog('Good morning, How are you?');
    } else if (message === 'adios') {
      session.endDialog('adios amigo');
    } else if (_.includes(message, 'search')) {
      session.beginDialog('searchFlight');
      next();
    } else {
      session.endDialog('Can you please repeat?');
    }
  },
  session => {
    session.endConversation();
  }
]);

// search flight
bot
  .dialog('searchFlight', [
    session => {
      //if there is no UserData get flight details
      if (!session.userData.date) {
        session.send('Welcome to flight search service!');
        session.beginDialog('getFlightDetails');
      } else {
        session.send('Searching...');
        setTimeout(() => {
          //get values
          const date = moment(session.userData.date).format('DD MMM');
          const depCity = _.capitalize(session.userData.depCity);
          const arrivalCity = _.capitalize(session.userData.arrivalCity);

          //send flight details
          session.send(
            `2 flights found from **${depCity}** to **${arrivalCity}** for ${date}`
          );

          //add adaptive cards
          var cards = [getFlightCard(session), getFlightCard(session)];
          var msg = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
          session.send(msg);
          session.endDialog();
        }, 1000);
      }
    }
  ])
  .triggerAction({
    matches: /^(search|find)\s.*flight/i
  });

//get the flight details from user
bot.dialog('getFlightDetails', [
  session => {
    builder.Prompts.text(session, 'Please enter departure city');
  },
  (session, results) => {
    session.userData.depCity = results.response;
    builder.Prompts.text(session, 'Please enter arrival city');
  },
  (session, results) => {
    session.userData.arrivalCity = results.response;
    builder.Prompts.time(session, 'Please enter arrival date');
  },
  (session, results) => {
    session.userData.date = builder.EntityRecognizer.resolveTime([
      results.response
    ]);
    session.beginDialog('getFlightClass');
    session.endDialog();
  }
]);

// flight class dialog
bot.dialog('getFlightClass', [
  session => {
    const msg = new builder.Message(session);
    msg.attachments([
      new builder.HeroCard(session)
        .title('Please select a flight class')
        .buttons([
          builder.CardAction.imBack(
            session,
            'Economy class is selected',
            'Economy'
          ),
          builder.CardAction.imBack(
            session,
            'Business class is selected',
            'Business'
          ),
          builder.CardAction.imBack(session, 'First class is selected', 'First')
        ])
    ]);
    session.send(msg);
    session.endDialog();
  }
]);

bot
  .dialog('selectFlightClass', [
    session => {
      let flightClass = session.message.text;
      flightClass = _.split(flightClass, ' ')[0];
      session.userData.flightClass = flightClass;
      session.beginDialog('searchFlight');
    }
  ])
  .triggerAction({
    matches: /^Economy|Business|First/i
  });

function getFlightCard(session) {
  const card = {
    contentType: 'application/vnd.microsoft.card.adaptive',
    content: {
      "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
      "version": "1.0",
      "type": "AdaptiveCard",
      "speak": `Your flight is confirmed for you and 3 other passengers from ${session.userData.arrivalCity} to ${session.userData.depCity} on Friday, October 10 8:30 AM`,
      "body": [
        {
          "type": "TextBlock",
          "text": "Passengers",
          "weight": "bolder",
          "isSubtle": false
        },
        {
          "type": "TextBlock",
          "text": "Sarah Hum",
          "separator": true
        },
        {
          "type": "TextBlock",
          "text": "Jeremy Goldberg",
          "spacing": "none"
        },
        {
          "type": "TextBlock",
          "text": "Evan Litvak",
          "spacing": "none"
        },
        {
          "type": "TextBlock",
          "text": "2 Stops",
          "weight": "bolder",
          "spacing": "medium"
        },
        {
          "type": "TextBlock",
          "text": "Fri, October 10 8:30 AM",
          "weight": "bolder",
          "spacing": "none"
        },
        {
          "type": "ColumnSet",
          "separator": true,
          "columns": [
            {
              "type": "Column",
              "width": 1,
              "items": [
                {
                  "type": "TextBlock",
                  "text": `${session.userData.arrivalCity}`,
                  "isSubtle": true
                },
                {
                  "type": "TextBlock",
                  "size": "extraLarge",
                  "color": "accent",
                  "text": "SFO",
                  "spacing": "none"
                }
              ]
            },
            {
              "type": "Column",
              "width": "auto",
              "items": [
                {
                  "type": "TextBlock",
                  "text": " "
                },
                {
                  "type": "Image",
                  "url": "http://adaptivecards.io/content/airplane.png",
                  "size": "small",
                  "spacing": "none"
                }
              ]
            },
            {
              "type": "Column",
              "width": 1,
              "items": [
                {
                  "type": "TextBlock",
                  "horizontalAlignment": "right",
                  "text": `${session.userData.depCity}`,
                  "isSubtle": true
                },
                {
                  "type": "TextBlock",
                  "horizontalAlignment": "right",
                  "size": "extraLarge",
                  "color": "accent",
                  "text": "AMS",
                  "spacing": "none"
                }
              ]
            }
          ]
        },
        {
          "type": "TextBlock",
          "text": "Non-Stop",
          "weight": "bolder",
          "spacing": "medium"
        },
        {
          "type": "TextBlock",
          "text": "Fri, October 18 9:50 PM",
          "weight": "bolder",
          "spacing": "none"
        },
        {
          "type": "ColumnSet",
          "separator": true,
          "columns": [
            {
              "type": "Column",
              "width": 1,
              "items": [
                {
                  "type": "TextBlock",
                  "text": `${session.userData.depCity}`,
                  "isSubtle": true
                },
                {
                  "type": "TextBlock",
                  "size": "extraLarge",
                  "color": "accent",
                  "text": "AMS",
                  "spacing": "none"
                }
              ]
            },
            {
              "type": "Column",
              "width": "auto",
              "items": [
                {
                  "type": "TextBlock",
                  "text": " "
                },
                {
                  "type": "Image",
                  "url": "http://adaptivecards.io/content/airplane.png",
                  "size": "small",
                  "spacing": "none"
                }
              ]
            },
            {
              "type": "Column",
              "width": 1,
              "items": [
                {
                  "type": "TextBlock",
                  "horizontalAlignment": "right",
                  "text": `${session.userData.arrivalCity}`,
                  "isSubtle": true
                },
                {
                  "type": "TextBlock",
                  "horizontalAlignment": "right",
                  "size": "extraLarge",
                  "color": "accent",
                  "text": "SFO",
                  "spacing": "none"
                }
              ]
            }
          ]
        },
        {
          "type": "ColumnSet",
          "spacing": "medium",
          "columns": [
            {
              "type": "Column",
              "width": "1",
              "items": [
                {
                  "type": "TextBlock",
                  "text": "Total",
                  "size": "medium",
                  "isSubtle": true
                }
              ]
            },
            {
              "type": "Column",
              "width": 1,
              "items": [
                {
                  "type": "TextBlock",
                  "horizontalAlignment": "right",
                  "text": "$4,032.54",
                  "size": "medium",
                  "weight": "bolder"
                }
              ]
            }
          ]
        }
      ]
    }
  };
  return card;
}
